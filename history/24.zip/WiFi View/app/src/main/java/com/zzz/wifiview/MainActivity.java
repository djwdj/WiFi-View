/** 佛祖保佑，永无bug🙏🙏🙏 */
package com.zzz.wifiview;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.lang.Process;

public class MainActivity extends Activity {
	ArrayList<Map<String, String>> mainList;
	ArrayList<File> list;
	List<String> fileList;
	PopupMenu popup;
	Context context = this;
	String out;
	
	String backupParentPath; // AppData/Backup/
	String backupPath;
	String filePath = "/data/misc/wifi/wpa_supplicant.conf";
	String pickerFilePath = null;
	
	int mode; // WorkMode
	/** mode = 0  |  Root
	  *  mode = 1  |  NoRoot
	  *  mode = 2  |  Reading */
	  
	int pmode; // FilePickerMode
	/** mode = 0  |  RestoreMode
	  *  mode = 1  |  ReadMode */
	
	java.util.Date utilDate = new java.util.Date();
	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// First - Output  |  AppData/Backup/zyyyyMMdd.conf
		backupParentPath = context.getExternalFilesDir("Backup").getPath();
		backupPath = backupParentPath + "/" + formatter.format(utilDate) +"-auto.conf";
		out = Output();
		
		if (check_root()) {
			mode = 0; // Root
			setContentView(R.layout.main);
			mainList = get_list();
			if (mainList == null) {
				Toast.makeText(MainActivity.this, "获取列表失败", Toast.LENGTH_LONG).show();
			} else {
				mode = 2; //Reading
				if (mainList.size() == 0) {
					Toast.makeText(MainActivity.this, "列表为空", Toast.LENGTH_LONG).show();
				} else {
					doWork();
				}
			}
		} else {
			mode = 1; // NoRoot
			Toast.makeText(MainActivity.this, "无法获取root", Toast.LENGTH_LONG).show();
		}
	}
	
	private void doWork() {
		ListView lv = (ListView) findViewById(R.id.lv);
		lv.setAdapter(new WiFiAdapter(this, mainList));
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
				popup = new PopupMenu(MainActivity.this, view);
				getMenuInflater().inflate(R.menu.copy,popup.getMenu());
				popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
					@Override
					public boolean onMenuItemClick(MenuItem item) {
						//if (mainList == null) return false;
						ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						switch(item.getItemId()) {
							case R.id.menu_ssid:
								clipboardManager.setPrimaryClip(ClipData.newPlainText(null, mainList.get(position).get("ssid")));
								break;
							case R.id.menu_password:
								clipboardManager.setPrimaryClip(ClipData.newPlainText(null, mainList.get(position).get("psk")));
								break;
							case R.id.menu_all:
								Map<String, String> s = mainList.get(position);
								clipboardManager.setPrimaryClip(ClipData.newPlainText(null, "SSID: " + s.get("ssid") + "\n" + "密码: " + s.get("psk")));
								break;
							default:
								return false;
						}
						Toast.makeText(MainActivity.this, "已复制", Toast.LENGTH_SHORT).show();
						return true;
					}
				});
			popup.show();
			}
		});
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0,0,0,"打开WiFi设置");
		menu.add(0,1,0,"备份");
		menu.add(0,2,0,"恢复");
		menu.add(0,3,0,"读取文件");
		menu.add(0,4,0,"Notice");
		menu.add(0,5,0,"Debug");
		
		if (mode == 0) {
			menu.getItem(4).setTitle("有ROOT权限");
			menu.getItem(4).setEnabled(false);
		} else if (mode == 1) {
			menu.getItem(1).setVisible(false);
			menu.getItem(2).setVisible(false);
			menu.getItem(4).setTitle("无ROOT权限");
			menu.getItem(4).setEnabled(false);
		} else if (mode == 2) {
			menu.getItem(4).setTitle("共 " + mainList.size() + " 条WiFi");
			menu.getItem(4).setEnabled(false);
		}
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case 0: // Opening WiFi Settings
				startActivity(new Intent().setClassName("com.android.settings","com.android.settings.wifi.WifiSettings"));
				return true;
			case 1: // Backup
				showBackupDialog();
				return true;
			case 2: //Restore
				pmode = 0; // RestoreMode
				showRestoreDialog();
				return true;
			case 3: // ReadFile
				pmode = 1; // ReadMode
				showFilePickerDialog();
				return true;
			case 5: // Debug
			mainList.notifyDataSetChanged();
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	
	private void showBackupDialog() {
		final EditText et = new EditText(this);
		AlertDialog.Builder BackupDialog = new AlertDialog.Builder(this);
		BackupDialog.setTitle("备份名称");
		BackupDialog.setView(et);
		et.setText( formatter.format(utilDate) + ".conf");
		BackupDialog.setPositiveButton("确定",new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog,int which) {
					backupPath = backupParentPath + "/" + et.getText().toString();
					out = Output();
					Toast.makeText(MainActivity.this,"备份完成", Toast.LENGTH_SHORT).show();
				}
			});
		BackupDialog.setNegativeButton("取消",new DialogInterface.OnClickListener(){@Override public void onClick(DialogInterface dialog, int which) {}});
		BackupDialog.setNeutralButton("分享",new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog,int which) {
					backupPath = backupParentPath + "/" + et.getText().toString();
					out = Output();
					File sendFile = new File(backupPath);
					Intent share = new Intent(Intent.ACTION_SEND);
					share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(sendFile));
					share.setType("*/*");
					startActivity(Intent.createChooser(share, "分享"));
				}
			});
		BackupDialog.show();
	}

	private void showRestoreDialog() {
		AlertDialog.Builder RestoreDialog = new AlertDialog.Builder(this);
		RestoreDialog.setTitle("警告");
		RestoreDialog.setMessage("该操作会将您所选择的文件覆盖设备 /data/misc/wifi 目录下的 wpa_supplicant.conf 文件，可能会造成未知后果。请确认该文件是否有效，以免造成不必要的损失！" + "\n" + "\n" + "当前已选择文件：" + "\n" + pickerFilePath); 
		RestoreDialog.setPositiveButton("确定",new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog,int which) {
					if (pickerFilePath != null) {
						Toast.makeText(MainActivity.this,"恢复完成", Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(MainActivity.this,"请选择文件！", Toast.LENGTH_SHORT).show();
					}				
				}
			});
		RestoreDialog.setNegativeButton("取消",new DialogInterface.OnClickListener(){@Override public void onClick(DialogInterface dialog, int which) {}});
		RestoreDialog.setNeutralButton("选择文件",new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog,int which) {
					showFilePickerDialog();
				}
			});
		RestoreDialog.show();
	}

	private void showFilePickerDialog() {
		list = new ArrayList<File>();
		getAllFiles(new File(backupParentPath));
		List<String> data = new ArrayList<String>();
		for(int i=0;i<list.size();i++) {
			String name = list.get(i).toString().substring(list.get(i).toString().lastIndexOf("/")+1,list.get(i).toString().length());
			data.add(name);
		}
		final String[] strings = new String[data.size()];
		data.toArray(strings);
		AlertDialog.Builder PickerDialog = new AlertDialog.Builder(MainActivity.this);
		PickerDialog.setTitle("选择文件");
		PickerDialog.setItems(strings, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					pickerFilePath = backupParentPath + "/" + strings[which];
					Toast.makeText(MainActivity.this, pickerFilePath, Toast.LENGTH_SHORT).show();
					if (pmode == 0) {
						showRestoreDialog();
					} else if (pmode == 1){
						Toast.makeText(MainActivity.this, "Read Mode", Toast.LENGTH_SHORT).show();
					}
				}
			});
		PickerDialog.show();
	}
	
	public ArrayList<Map<String, String>> get_list() {
        try {
            ReadFile file = new ReadFile(backupParentPath + "/" + formatter.format(utilDate) + "-auto.conf");
            return file.getPasswordList(this.context);
        } catch (Exception e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e("Read", e.getMessage());
            return null;
        }
    }
	
	public boolean run_cmd(String command) {
        Process process = null;
        DataOutputStream os = null;
        int rt = 1;
        try {
            process = Runtime.getRuntime().exec("su");
            os = new DataOutputStream(process.getOutputStream());
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            rt = process.waitFor();
        } catch (Exception e) {
            return false;
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (process != null) {
                process.destroy();
            }
        }
        return rt == 0;
    }

    public boolean check_root() {
        try {
            try {
                return run_cmd("system/bin/mount -o rw,remount -t rootfs /data");
            } catch (Exception e) {
                Toast.makeText(context, "Error (Root Permission) " + ":" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }
	
    private String Output() {
        out = null;
        Process process = null;
        DataOutputStream outputStream = null;
        DataInputStream inputStream = null;
        StringBuffer sBuffer = new StringBuffer();
		File tempDir = new File(backupParentPath);
        if (!tempDir.exists())tempDir.mkdir();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(backupPath);
            process = Runtime.getRuntime().exec("su");
            outputStream = new DataOutputStream(process.getOutputStream());
            inputStream = new DataInputStream(process.getInputStream());
            outputStream.writeBytes("cat " + filePath + "\n");
            outputStream.writeBytes("exit\n");
            outputStream.flush();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String temp = null;
            while ((temp = reader.readLine()) != null) {
                fileOutputStream.write((temp + "\n").getBytes());
                sBuffer.append(temp);
            }
            out = sBuffer.toString();
            reader.close();
            fileOutputStream.close();
            inputStream.close();
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (outputStream != null)
                    outputStream.close();
                if (inputStream != null)
                    inputStream.close();
                process.destroy();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return out;
    }
	
	class WiFiAdapter extends BaseAdapter {
		private Context context;
		ArrayList<Map<String,String>> mainLlist;

		public WiFiAdapter(Context context, ArrayList<Map<String,String>> list) {
			super();
			this.context = context;
			this.mainLlist = list;
		}

		@Override
		public int getCount() {
			return mainLlist.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			Map<String,String> obj = mainLlist.get(position);
			if (convertView != null) {
				holder = (ViewHolder) convertView.getTag();
			} else {
				convertView = View.inflate(context,R.layout.item, null);
				holder = new ViewHolder();
				holder.ssid = (TextView) convertView.findViewById(R.id.ssid);
				holder.password = (TextView) convertView.findViewById(R.id.password);
				convertView.setTag(holder);
			}
			holder.ssid.setText(obj.get("ssid"));
			holder.password.setText(obj.get("psk"));
			return convertView;
		}
	}
	
	class ViewHolder {
		public TextView ssid;
		public TextView password;
	}
	
    private void getAllFiles(File root) {
		File files[] = root.listFiles();
		if(files != null)
			for(File f:files) {
				if(f.isDirectory()) {
					getAllFiles(f);
				}
				else{
					this.list.add(f);
				}
			}
		}
		
}
